#include <bits/stdc++.h>
using namespace std;
class Node
{
public:
    int val;
    Node *next;
    Node(int val)
    {
        this->val = val;
        this->next = NULL;
    }
};
void insertt_at_tail(Node *&head, int val)
{
    Node *newNode = new Node(val);
    if (head == NULL)
    {
        cout << endl
             << "insert in head" << endl
             << endl;
        head = newNode;
        return;
    }
    cout << endl
         << "insert in tail" << endl
         << endl;

    Node *tmp = head;
    while (tmp->next != NULL)
    {
        tmp = tmp->next;
    }
    tmp->next = newNode;
}
void printlist(Node *head)
{
    cout << endl
         << "LIST ARE" << endl
         << endl;
    Node *tmp = head;
    while (tmp != NULL)
    {
        cout << tmp->val << endl;
        tmp = tmp->next;
    }
}
void ins_any_position(Node *head, int pos, int val)
{
    Node *newNode = new Node(val);
    Node *tmp = head;
    for (int i = 1; i <= pos - 1; i++)
    {
        tmp = tmp->next;
    }
    newNode->next = tmp->next;
    tmp->next = newNode;
    cout << endl
         << "Insert position number : " << pos << endl
         << endl;
}
void ins_head(Node *&head, int val, int pos)
{
    Node *newNode = new Node(val);
    newNode->next = head;
    head = newNode;
    cout << endl
         << "Insert position in : " << pos << endl
         << endl;
}
void del_any_pos(Node *head, int pos)
{
    Node *tmp = head;
    for (int i = 1; i <= pos - 1; i++)
    {
        tmp = tmp->next;
    }
    Node *deleNode = tmp->next;
    tmp->next = tmp->next->next;
    delete deleNode;
    cout<<endl << "delete position in : " << pos << endl
         << endl;
}
void del_head_pos(Node *&head, int pos)
{
    Node *deleNode = head;
    head = head->next;
    delete deleNode;
    cout<<endl << "delete position in : " << pos << endl
         << endl;
}
int main()
{
    Node *head = NULL;
    while (true)
    {
        cout << "Option 1 insert" << endl;
        cout << "Option 2 printlist" << endl;
        cout << "Option 3 insert any position" << endl;
        cout << "Option 4 delete any position" << endl;
        cout << "Option 5 terminate" << endl;
        cout << "Enter your option: ";
        int op;
        cin >> op;
        if (op == 1)
        {
            cout << "Enter your value: ";
            int val;
            cin >> val;
            insertt_at_tail(head, val);
        }
        else if (op == 2)
        {
            printlist(head);
        }
        else if (op == 3)
        {
            cout << "Enter your position: ";
            int pos;
            cin >> pos;
            cout << "Enter your value: ";
            int val;
            cin >> val;
            if (pos == 0)
            {
                ins_head(head, val, pos);
            }
            else
            {
                ins_any_position(head, pos, val);
            }
        }
        else if (op == 4)
        {
            cout << "Enter your position: ";
            int pos;
            cin >> pos;
            if (pos == 0)
            {
                del_head_pos(head, pos);
            }
            else
            {
                del_any_pos(head, pos);
            }
        }
        else if (op == 5)
        {
            break;
        }
    }

    return 0;
}